const String appTitle = "AdviseMe";
const String qouteAR = "انصحني ! أفضل نصيحة بأفضل تطبيق";

const String qouteEN = "GET THE BEST ADVICE YOU NEED";
const String error = "Don't panic, could be interent problem!";
const String adminEmail = "admin@admin.com";
const String adminPassword = "admin";

const String verifyEn = "Please check your email address at :";
const String verifyAr = "من فضلك أدخل كود التفعيل المرسل على البريد التالي";
const String url = "http://192.168.1.102:80/advise_me/";
