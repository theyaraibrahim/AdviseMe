part of 'language_bloc.dart';

abstract class LanguageState extends Equatable {
  const LanguageState();
}

class Arabic extends LanguageState {
  @override
  List<Object> get props => [];
}

class English extends LanguageState {
  @override
  List<Object> get props => [];
}
