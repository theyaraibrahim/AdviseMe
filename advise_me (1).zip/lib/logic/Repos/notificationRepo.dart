import 'dart:convert';

import 'package:http/http.dart' as http;

import '../data center/data_center.dart';

class NotificationRepo {
  static Future<String> getNotificationsNumber(String accountType) async {
    http.StreamedResponse response = await DataCenter.contactCenter(
        "http://192.168.1.102:80/advise_me/getNotification.php",
        {"accountType": accountType});
    if (response.statusCode == 200) {
      var worked = await http.Response.fromStream(response);
      final result = jsonDecode(worked.body) as Map<String, dynamic>;
      if (result["code"].toString() == "1") {
        return result["notifications"].toString();
      } else {
        return "0";
      }
    } else {
      return "0";
    }
  }
}

