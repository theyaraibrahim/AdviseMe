package com.example.advise_me

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
